//this
//Ex1
var data = {
  info: "My name is Moshe",
  logInfo: function(){
      console.log(this.info)
  }
};

data.logInfo();

//Ex2
var user = {
  name: 'Moshe Shoker',
  getName: function(){
      return this.name;
  }

};
console.log(user.getName());

//Ex3
var mail ={
  port: function(){
      return 225;
  },
  send: function(){
      return 'Request to port: ' + this.port();
  }

};
console.log(mail.send());

//Ex4

var data = {
  articles: ['article1','article2','article3','article4'],
  print: function(){
      var $d = document.getElementById('content');
      for (var article of this.articles) {
          $d.innerHTML += '<p>'+article + '</p>';
      }
  }

};
data.print();

//Ex5
var ob = {
 name: null,
 setName: function(name){
  this.name = name;
 },
 getName :function(){
  return this.name;
 }
};

var result = ob.setName('Moshe');
console.log(ob.getName());

//Ex6

var product = {
  sizes: ['S','M','L','XL','XXL'],
  print: function(){
      $s = document.getElementById('sizes');
      $s.innerHTML = '<option selected disabled>Select Size:</option>'
      for (var size of this.sizes) {
          $s.innerHTML += '<option>'+ size + '</option>';
      }
  }

};

product.print();

//Ex7

var product = {
  id: 7,
  price: 7.5,
  title: 'milk',
  get: function(myProperty){
      return this[myProperty]
  },
  set: function(myProperty, newValue){
      this[myProperty] = newValue;
  }

};

var p1 = product.get('id');
console.log(p1);

product.set('price',10);
console.log(product['price']);

//classes homework
//Ex1

function Requset1() {
    this.url = "www.googel.com";
  }
  let rq = new Requset1();
  console.log(rq.url);
  //Ex2
  let mail = function () {
    (this.port = 225),
      (this.send = function () {
        return "Mail send by port " + this.port;
      });
  };
  let m = new mail().send();
  console.log(m);
  //Ex3
  function Hash() {
    this.key = null;
    this.gettr = function () {
      return this.key;
    };
    this.setter = function (keyn) {
      this.key = keyn;
    };
  }
  let hash = new Hash();
  hash.setter(3);
  console.log(hash.gettr());
  //Ex4
  function Http() {
    this.url = "www.faceb.com";
    this.port = "https";
  }
  let ht = new Http();
  delete ht.url;
  console.log(ht);
  ht.port = "htt";
  ht.ptt = 5050;
  ht.ma = function () {
    console.log(this.ptt);
  };
  ht.ma();
  //Ex5
  function Db() {
    let a = document.getElementById("names-list");
    this.name = ["yoni", "tal", "gal"];
    this.rend = function () {
      for (let item in this.name) {
        a.innerHTML += "<li>" + this.name[item] + "</li>";
      }
    };
  }
  let db = new Db();
  db.rend();
  //Ex6
  function Animal() {
    this.age = 3;
    this.name = "cat";
    this.set = function (name1) {
      this.name = name1;
    };
  }
  let cat = new Animal();
  let keys = Object.keys(cat);
  let val = Object.values(cat);
  for (let i = 0; i < keys.length; i++) {
    console.log(keys[i] + ": " + val[i]);
  }
  
  //Ex7
  let mail1 = function Mail(email) {
    this.email = email;
    this.sendMail = function () {
      return "Mail send to " + this.email;
    };
  };
  let a = new mail1("avi");
  console.log(a.sendMail());